package com.vikash.modal;
import java.util.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;

import java.io.*;
import com.vikash.services.MidService;
//import com.vikash.repository.UserRepository;

@Entity
@Table(name="mid")
public class Mid {
	@Id
	private int id;
	public String tickler;
	public String LTP;
	public String High;
	public String Open;
	public String Low;
	public String Prev_close;
	public String change;
	public Mid()
	{
		
	}
	public Mid(String tickler,
	String LTP,
	String Open,
	String High,
	String Low,
	String Prev_close,
	String change)
	{
		super();
		this.tickler=tickler;
		this.LTP=LTP;
		this.Open=Open;
		this.High=High;
		this.Low=Low;
		this.Prev_close=Prev_close;
		this.change=change;
	}
//			public ArrayList<Mid> main1() throws IOException
//			{
//				ArrayList<Mid>MidList=new ArrayList<Mid>();
//		File f=new File("D://citi bridge/NSE Stocks Mid.csv");
//		BufferedReader br = new BufferedReader(new FileReader(f));
//		//System.out.println("........");
//		
//		if(!f.exists())
//		{
//			System.out.println("Sorry file does not exist...");
//		}
//		int i=0;
//		br.readLine();
//		while(i<5)
//		{
//			String st;
//			if((st=br.readLine())!=null)
//			{
//				String arr[]=st.split(",");
//				Mid temp=new Mid(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6]);
//				MidList.add(temp);
//				//midcap(Mid);
//				//ArrayList<Mid>l=midcap();
//				//MidRepository.class.getMethod(saveMyUser, Mid);
//				//mid.saveMyUser(MidList.get(i));
//				i++;
//			}
//		}
//		return MidList;
//			}
//			public static void main(String args[]) throws IOException
//			{
//				Mid m=new Mid();
//				ArrayList<Mid>l=m.main1();
//				System.out.println(l);
//			}
}
