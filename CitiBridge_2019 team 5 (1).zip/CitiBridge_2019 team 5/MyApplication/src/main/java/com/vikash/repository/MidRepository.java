package com.vikash.repository;

import org.springframework.data.repository.CrudRepository;

import com.vikash.modal.Mid;
//import com.vikash.modal.User;

public interface MidRepository extends CrudRepository<Mid, Integer> {

}
