package com.vikash.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.transaction.Transactional;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import java.util.*;
import java.io.*;
import com.vikash.modal.User;
import com.vikash.modal.Mid;
import com.vikash.repository.MidRepository;
@DynamicUpdate
@Service
@Transactional
public class MidService {

	public MidRepository midRepository;
	public MidService(MidRepository midRepository) {
		this.midRepository=midRepository;
	}
	
//	public void saveMyMid(Mid user ) {
//		midRepository.save(user);	}
//	public ArrayList<Mid> showAllUsers(){
//		ArrayList<Mid> users = new ArrayList<Mid>();
//		for(Mid user :midRepository.findAll()) {
//			users.add(user);
//		}
//		
//		return users;
//	}
	public List<Mid>display() throws IOException,NullPointerException
	{
		List<Mid>MidList=new ArrayList<Mid>();
		File f=new File("D://citi bridge/NSE Stocks Mid.csv");
		BufferedReader br = new BufferedReader(new FileReader(f));
		if(!f.exists())
		{
			System.out.println("Sorry file does not exist...");
		}
		int i=0;
		br.readLine();
		while(i<5)
		{
			String st;
			if((st=br.readLine())!=null)
			{
				String arr[]=st.split(",");
				Mid temp=new Mid(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6]);
				MidList.add(temp);
				i++;
			}
		}
		return MidList;
	}
}
