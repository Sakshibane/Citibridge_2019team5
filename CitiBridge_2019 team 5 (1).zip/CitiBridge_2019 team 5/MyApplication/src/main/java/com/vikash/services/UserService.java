package com.vikash.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.transaction.Transactional;

import org.hibernate.annotations.DynamicUpdate;
import org.springframework.stereotype.Service;
import com.vikash.modal.User;
import com.vikash.repository.UserRepository;

@DynamicUpdate
@Service
@Transactional
public class UserService {
	
	private final UserRepository userRepository;
	public UserService(UserRepository userRepository) {
		this.userRepository=userRepository;
	}
	
	public void saveMyUser(User user ) {
		userRepository.save(user);
	}
	
	public List<User> showAllUsers(){
		List<User> users = new ArrayList<User>();
		for(User user : userRepository.findAll()) {
			users.add(user);
		}
		
		return users;
	}
	
	public void deleteMyUser(int id) {
		userRepository.delete(id);
	}
	
	public User editUser(int id) {
		return userRepository.findOne(id);
	}
	
	public User findByUsernameAndPassword(String username, String password) {
		return userRepository.findByUsernameAndPassword(username, password);
	}
	public String findByUsername(String username) {
		int i=0;
		for(i=0;i<userRepository.count();i++) {
			if(username.equals(userRepository.findOne(i).getUsername()))
				return "false";
		}
        return "true";
		
	}
//	public String usernameFetch(String username) {
//		int i=0;
//		System.out.println(username);
//		for(i=0;i<userRepository.count();i++) {
//			System.out.println("********");
//			if(username.equals(userRepository.findByUsername(username)))
//			{
//				System.out.println("For"+username);
//				return username;
//			}
//		}
//		System.out.println("For"+username);
//        return "true";
//				
//	}

	}

	